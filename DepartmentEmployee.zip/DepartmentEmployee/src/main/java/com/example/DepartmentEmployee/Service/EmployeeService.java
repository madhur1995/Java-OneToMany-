package com.example.DepartmentEmployee.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.DepartmentEmployee.Entity.Department;
//import com.example.DepartmentEmployee.Entity.Department;
import com.example.DepartmentEmployee.Entity.Employee;
import com.example.DepartmentEmployee.Repository.DepartmentRepository;
import com.example.DepartmentEmployee.Repository.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;

	@Autowired
	private DepartmentRepository departmentRepository;

	public List<Employee> getAllEmployees() {
		return employeeRepository.findAll();
	}

	public Employee addEmployee(Employee employee) {

		/*
		 * Department dept =
		 * departmentRepository.findById(employee.getDepartment().getId()).orElse(null);
		 * if (null == dept) { dept = new Department(); }
		 * dept.setDeptName(employee.getDepartment().getDeptName());
		 * employee.setDepartment(dept);
		 */
		return employeeRepository.save(employee);
	}

	public Employee editEmployees(Employee entity) {
		return employeeRepository.save(entity);
	}

	public void deleteEmployees(Integer id) {
		employeeRepository.deleteById(id);
	}

	public Department addDepartment(Department department) {

		return departmentRepository.save(department);
	}

	public List<String> getAllEmployeesNames() {

		List<Employee> empList = employeeRepository.findAll();
		List<String> empNames = new ArrayList<>();
		for (Employee e : empList) {
			e.getName();
			empNames.add(e.getName());

		}

		List<String> list = empNames.stream().sorted().collect(Collectors.toList());
		return list;
	}

}
